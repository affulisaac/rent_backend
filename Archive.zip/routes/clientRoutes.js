// const express = require('express')
// const router = express.Router()
// const { getClients, addClient, deleteClient, updateClient, getClient }  = require('../controllers/clientController')

// router.route('/').get(getClients).post(addClient)
// router.route('/:id').put(updateClient).delete(deleteClient).get(getClient) 

// module.exports = router